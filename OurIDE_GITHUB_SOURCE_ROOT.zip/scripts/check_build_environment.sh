#!/usr/bin/env bash
set -u

ok=0
warn=0
fail=0

check() {
  local label="$1"; shift
  if "$@" >/dev/null 2>&1; then
    printf '[OK]   %s\n' "$label"
    ok=$((ok+1))
  else
    printf '[FAIL] %s\n' "$label"
    fail=$((fail+1))
  fi
}

printf '%s\n' 'OurIDE Build Environment Doctor'
printf '%s\n' 'Required baseline: AGP 9.4.0 / Gradle 9.6.0 / JDK 17 / SDK 36 / Build Tools 36.0.0'
printf '\n'

if command -v java >/dev/null 2>&1; then
  java_version="$(java -version 2>&1 | head -1)"
  printf '[INFO] Java: %s\n' "$java_version"
else
  printf '[FAIL] Java executable not found\n'
  fail=$((fail+1))
fi

if [ -n "${JAVA_HOME:-}" ]; then
  printf '[INFO] JAVA_HOME=%s\n' "$JAVA_HOME"
else
  printf '[WARN] JAVA_HOME is not set\n'
  warn=$((warn+1))
fi

if [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  sdk="$ANDROID_SDK_ROOT"
elif [ -n "${ANDROID_HOME:-}" ]; then
  sdk="$ANDROID_HOME"
  printf '[WARN] Using legacy ANDROID_HOME instead of ANDROID_SDK_ROOT\n'
  warn=$((warn+1))
else
  sdk=""
fi

if [ -n "$sdk" ] && [ -d "$sdk" ]; then
  printf '[OK]   Android SDK: %s\n' "$sdk"
  ok=$((ok+1))
else
  printf '[FAIL] Android SDK path is not available\n'
  fail=$((fail+1))
fi

if [ -n "$sdk" ]; then
  if [ -d "$sdk/platforms/android-36" ]; then
    printf '[OK]   SDK Platform android-36\n'
    ok=$((ok+1))
  else
    printf '[FAIL] SDK Platform android-36 is missing\n'
    fail=$((fail+1))
  fi

  if [ -d "$sdk/build-tools/36.0.0" ]; then
    printf '[OK]   Build Tools 36.0.0\n'
    ok=$((ok+1))
  else
    printf '[FAIL] Build Tools 36.0.0 is missing\n'
    fail=$((fail+1))
  fi
fi

if [ -x "./gradlew" ]; then
  printf '[OK]   Gradle wrapper is present\n'
  ok=$((ok+1))
else
  printf '[FAIL] Gradle wrapper is missing or not executable\n'
  fail=$((fail+1))
fi

if [ -f "gradle/wrapper/gradle-wrapper.properties" ]; then
  grep -q 'gradle-9\.6' gradle/wrapper/gradle-wrapper.properties \
    && printf '[OK]   Wrapper targets Gradle 9.6\n' && ok=$((ok+1)) \
    || printf '[FAIL] Wrapper does not target Gradle 9.6\n' && fail=$((fail+1))
fi

printf '\nSummary: OK=%s WARN=%s FAIL=%s\n' "$ok" "$warn" "$fail"

if [ "$fail" -eq 0 ]; then
  exit 0
fi
exit 1
