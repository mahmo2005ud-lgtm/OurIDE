# OurIDE Phase 2 — Modern Build Engine

Baseline: AGP 9.4.0 / Gradle 9.6.0 / JDK 17 / SDK 36.

Changes in this phase:
- Updated bundled Gradle wrapper references from 8.6 to 9.6 where present.
- Updated internal sample project AGP from 8.2.2 to 9.4.0.
- Kept project templates on fixed, non-dynamic plugin versions.
- Kept LuxDim/application source logic untouched.

Build verification note:
The current container cannot download Gradle distributions or Maven artifacts, so a full online Gradle build cannot be truthfully marked successful here. Static configuration checks are performed instead.
